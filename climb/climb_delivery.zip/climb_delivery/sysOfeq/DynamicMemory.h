#pragma once

void fillInFibonacciNumbers(int result[], int length);
void createFibonacci();
